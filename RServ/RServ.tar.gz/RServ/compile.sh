javac -cp javax.mail.jar:sigar.jar:. *.java
