nohup /usr/java/jdk1.8.0_60/bin/java -cp javax.mail.jar:sigar.jar:p4java.jar:. RServer > RServer.out 
