nohup /usr/java/jdk1.8.0_60/bin/java -cp javax.mail.jar:sigar.jar:. RServer > RServer.out 
