import java.io.File;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import com.perforce.p4java.client.IClient;
import com.perforce.p4java.client.IClientViewMapping;
import com.perforce.p4java.core.IMapEntry.EntryType;
import com.perforce.p4java.core.file.FileSpecBuilder;
import com.perforce.p4java.core.file.IFileSpec; 
import com.perforce.p4java.impl.generic.client.ClientView;
import com.perforce.p4java.impl.generic.client.ClientView.ClientViewMapping;
import com.perforce.p4java.impl.mapbased.client.Client;
import com.perforce.p4java.server.IServer;
import com.perforce.p4java.server.ServerFactory;

public class PerforceScript {

	static String workspacePath = "depot/GAI";       
	static String depotPath = "//GAI/"; 	           
	static String serverURL = "p4java://go-perforce.rws.ad.ea.com:4487";    
	static boolean forceSync = true; 

	static String user = "EAHQ\\svc_originanalytics";
	
	public static byte[] key = {
	        0x74, 0x68, 0x69, 0x73, 0x49, 0x73, 0x41, 0x53, 0x65, 0x63, 0x72, 0x65, 0x74, 0x4b, 0x65, 0x79
	};
	
	private static String value = "34B6E109F8FD3E9C7F7C7403598ABA2D"; 
	
	public static void main(String[] args) throws Exception {
		update(); 
	}
	
	public static void update() throws Exception {
				
        final SecretKeySpec secretKey = new SecretKeySpec(PerforceScript.key, "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, secretKey); 
		
		// connect to the server 
		IServer server = ServerFactory.getServer(serverURL, null);    
		server.connect(); 
	    server.setUserName(user);   
    	server.login(new String(cipher.doFinal(DatatypeConverter.parseHexBinary(value))));      	  
	    System.out.println(server.getLoginStatus());
	    System.out.println("Forcing Sync? " + forceSync); 

	    // create the workspace name 
	    File workingDirectory = new File(workspacePath);
	    String workspaceName  = user 
	    		+ "-" + InetAddress.getLocalHost().getHostName()
	    		+ "-" + workingDirectory.getCanonicalPath().replaceAll("[/ ~]", "-");
	    
	    // create the client 
	    IClient client = new Client(server);
        client.setName(workspaceName);
        client.setRoot(workingDirectory.getAbsolutePath());
        client.setOwnerName(user);
        client.setHostName(InetAddress.getLocalHost().getHostName());

        // create the view mapping  
        List<IClientViewMapping> viewMappings = new ArrayList<IClientViewMapping>();
        IClientViewMapping viewMapping = new ClientViewMapping();
        viewMapping.setDepotSpec(depotPath + "...");
        viewMapping.setRight("//" + workspaceName + "/...");
        viewMapping.setType(EntryType.INCLUDE);
        viewMapping.setOrder(0); 
        viewMappings.add(viewMapping);
        ClientView view = new ClientView(client, viewMappings);
        client.setClientView(view);

        // get the updated client from the server 
        server.createClient(client); 
        client = server.getClient(workspaceName);	    	    
        client.setServer(server); 
        server.setCurrentClient(client);

        // sync files
        List<IFileSpec> fileSpecs = FileSpecBuilder.makeFileSpecList(depotPath + "...");
        fileSpecs = server.getDepotFiles(fileSpecs, Boolean.FALSE);
        fileSpecs = FileSpecBuilder.getValidFileSpecs(fileSpecs);
        List<IFileSpec> syncedFiles = server.getCurrentClient().sync(fileSpecs, forceSync, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);

        System.out.println("Synchronized files: " + syncedFiles.size());         
        server.disconnect(); 
	}	
		
	public static String getProperty(String key, String value) {
		return System.getProperty(key) != null ? System.getProperty(key) : value;
	}	
}
