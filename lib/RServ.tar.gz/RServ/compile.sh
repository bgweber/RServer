javac -cp javax.mail.jar:sigar.jar:p4java.jar:. *.java
